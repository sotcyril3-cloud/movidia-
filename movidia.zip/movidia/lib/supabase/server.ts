import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';

// Client "serveur" : respecte la session de l'utilisateur connecté (RLS actif)
export function createClient() {
  const cookieStore = cookies();
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
        set(name: string, value: string, options: any) {
          try { cookieStore.set({ name, value, ...options }); } catch {}
        },
        remove(name: string, options: any) {
          try { cookieStore.set({ name, value: '', ...options }); } catch {}
        },
      },
    }
  );
}

// Client "admin" : utilisé UNIQUEMENT dans les routes serveur de confiance
// (webhooks Stripe, génération vidéo). Contourne RLS. Ne jamais exposer
// la clé service_role au navigateur.
import { createClient as createSupabaseClient } from '@supabase/supabase-js';
export function createAdminClient() {
  return createSupabaseClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );
}
