import RunwayML, { TaskFailedError } from '@runwayml/sdk';

const client = new RunwayML({ apiKey: process.env.RUNWAYML_API_SECRET });

export type GenerateVideoResult =
  | { ok: true; videoUrl: string; taskId: string }
  | { ok: false; error: string; taskId?: string };

/**
 * Lance une génération vidéo texte->vidéo sur Runway (Gen-4.5) et attend
 * la fin du traitement. Une vidéo de 5s coûte des crédits Runway réels
 * (vérifie les tarifs en vigueur sur ton compte Runway).
 */
export async function generateVideoFromText(
  prompt: string,
  opts: { ratio?: string; duration?: 5 | 10 } = {}
): Promise<GenerateVideoResult> {
  try {
    const task = await client.textToVideo
      .create({
        model: 'gen4.5',
        promptText: prompt,
        ratio: opts.ratio ?? '1280:720',
        duration: opts.duration ?? 5,
      })
      .waitForTaskOutput({ timeout: 1000 * 60 * 8 }); // 8 min max d'attente

    const videoUrl = Array.isArray((task as any).output)
      ? (task as any).output[0]
      : undefined;

    if (!videoUrl) {
      return { ok: false, error: 'Runway n\'a renvoyé aucune vidéo.', taskId: task.id };
    }

    return { ok: true, videoUrl, taskId: task.id };
  } catch (err) {
    if (err instanceof TaskFailedError) {
      return { ok: false, error: 'La génération a échoué côté Runway.' };
    }
    if (err instanceof RunwayML.APIError) {
      return { ok: false, error: `Erreur API Runway (${err.status}): ${err.message}` };
    }
    return { ok: false, error: err instanceof Error ? err.message : 'Erreur inconnue.' };
  }
}
