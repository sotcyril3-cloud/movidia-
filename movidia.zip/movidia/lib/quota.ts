type Profile = {
  is_owner: boolean;
  plan: 'free' | 'pro';
  subscription_status: 'inactive' | 'active' | 'canceled' | 'past_due';
};

/**
 * Règles :
 * - Propriétaire (is_owner = true) -> toujours illimité, gratuit, peu importe Stripe.
 * - Abonné "pro" avec abonnement Stripe actif -> illimité.
 * - Tout le monde d'autre (free / abonnement inactif ou annulé) -> doit s'abonner.
 */
export function canGenerateVideo(profile: Profile): { allowed: boolean; reason?: string } {
  if (profile.is_owner) return { allowed: true };
  if (profile.plan === 'pro' && profile.subscription_status === 'active') {
    return { allowed: true };
  }
  return {
    allowed: false,
    reason: 'Un abonnement Pro actif est nécessaire pour générer des vidéos.',
  };
}
