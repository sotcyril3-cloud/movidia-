-- ============================================================
-- SCHÉMA MOVIDIA — à exécuter dans Supabase > SQL Editor
-- ============================================================

-- Table des profils (1 ligne par utilisateur, liée à auth.users de Supabase Auth)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  is_owner boolean not null default false,
  plan text not null default 'free' check (plan in ('free', 'pro')),
  subscription_status text not null default 'inactive'
    check (subscription_status in ('inactive', 'active', 'canceled', 'past_due')),
  stripe_customer_id text,
  stripe_subscription_id text,
  videos_generated_this_month integer not null default 0,
  quota_reset_at timestamptz not null default (now() + interval '30 days'),
  created_at timestamptz not null default now()
);

-- Table des vidéos générées (historique + lien vers le fichier Runway)
create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  prompt text not null,
  runway_task_id text,
  status text not null default 'queued' check (status in ('queued','processing','completed','failed')),
  video_url text,
  error_message text,
  auto_generated boolean not null default false, -- true = générée automatiquement après abonnement
  created_at timestamptz not null default now()
);

create index if not exists videos_user_id_idx on public.videos(user_id);

-- ============================================================
-- Création automatique du profil à l'inscription
-- ============================================================
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, is_owner)
  values (
    new.id,
    new.email,
    -- Le compte dont l'email correspond à OWNER_EMAIL (configuré côté app)
    -- est marqué propriétaire automatiquement via l'API après inscription.
    false
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- Sécurité ligne par ligne (RLS) — chaque utilisateur ne voit que ses données
-- ============================================================
alter table public.profiles enable row level security;
alter table public.videos enable row level security;

create policy "Lecture de son propre profil"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Mise à jour de son propre profil (champs limités côté API)"
  on public.profiles for update
  using (auth.uid() = id);

create policy "Lecture de ses propres vidéos"
  on public.videos for select
  using (auth.uid() = user_id);

create policy "Création de ses propres vidéos"
  on public.videos for insert
  with check (auth.uid() = user_id);

-- Le service_role (utilisé uniquement côté serveur, jamais exposé au navigateur)
-- contourne RLS automatiquement — c'est lui qui gère les webhooks Stripe
-- et la mise à jour des quotas/statuts d'abonnement.
