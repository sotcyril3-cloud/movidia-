# Movidia — Guide de mise en ligne réelle

Ce projet est un vrai site Next.js fonctionnel : comptes utilisateurs, abonnement
Stripe, génération vidéo IA via Runway. Il ne fait rien tout seul tant que tu
n'as pas connecté les 3 services ci-dessous (chacun prend 5-15 min).

## Ce qui est déjà fait dans le code
- Inscription / connexion (Supabase Auth)
- Page dashboard avec génération vidéo
- Abonnement Pro via Stripe Checkout
- Webhook Stripe qui active l'abonnement ET lance automatiquement une
  première vidéo IA de bienvenue dès le paiement validé
- Compte "propriétaire" (toi) avec génération illimitée et gratuite,
  sans jamais passer par Stripe
- Les abonnés Pro actifs ont une génération illimitée tant que l'abonnement
  est actif

## Étape 1 — Supabase (comptes + base de données), ~10 min
1. Crée un compte sur https://supabase.com et un nouveau projet.
2. Dans **SQL Editor**, colle et exécute tout le contenu de `supabase/schema.sql`.
3. Dans **Project Settings > API**, copie :
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` (secret) → `SUPABASE_SERVICE_ROLE_KEY`
4. Dans **Authentication > Providers**, active "Email" (activé par défaut).
   Tu peux désactiver "Confirm email" pendant les tests pour aller plus vite.

## Étape 2 — Stripe (abonnements), ~10 min
1. Crée un compte sur https://dashboard.stripe.com
2. **Product catalog > + Add product** → nom "Movidia Pro", prix récurrent
   mensuel (ex: 29€/mois). Copie l'ID du prix (`price_...`) →
   `STRIPE_PRICE_ID_PRO`.
3. **Developers > API keys** → copie la clé secrète → `STRIPE_SECRET_KEY`.
4. **Developers > Webhooks > + Add endpoint** :
   - URL : `https://TON-DOMAINE.com/api/stripe/webhook`
   - Événements à écouter : `checkout.session.completed`,
     `customer.subscription.updated`, `customer.subscription.deleted`
   - Copie le "Signing secret" → `STRIPE_WEBHOOK_SECRET`
5. Pour tester en local avant d'avoir un domaine : installe la Stripe CLI puis
   `stripe listen --forward-to localhost:3000/api/stripe/webhook`

## Étape 3 — Runway (génération vidéo IA), ~5 min
1. Crée un compte développeur sur https://dev.runwayml.com
2. Ajoute des crédits (la génération vidéo est payante à l'usage — vérifie
   les tarifs actuels dans ton dashboard Runway).
3. Crée une clé API → `RUNWAYML_API_SECRET`.

## Étape 4 — Configuration finale
1. Renomme `.env.example` en `.env.local` et remplis toutes les valeurs.
2. Mets ton adresse email dans `OWNER_EMAIL` — **crée ton compte avec cette
   adresse exacte** sur le site une fois lancé : il sera automatiquement
   marqué comme propriétaire (génération illimitée et gratuite).

## Lancer en local
```bash
npm install
npm run dev
```
Ouvre http://localhost:3000

## Déployer en production (recommandé : Vercel)
```bash
npm install -g vercel
vercel
```
Puis ajoute toutes les variables de `.env.local` dans Vercel
(Project Settings > Environment Variables), et mets à jour
`NEXT_PUBLIC_SITE_URL` avec ton vrai domaine.
N'oublie pas de remettre à jour l'URL du webhook Stripe (étape 2.4) avec
ton domaine final une fois déployé.

## Important à savoir
- **Coûts réels** : chaque vidéo générée via Runway coûte de l'argent
  (facturé à ton compte Runway), peu importe qui la génère (toi ou un
  abonné Pro). Le système ne plafonne pas le nombre de vidéos pour les
  comptes Pro/propriétaire — surveille ta consommation Runway.
- **Le webhook Stripe doit être accessible publiquement** (pas en
  localhost) pour fonctionner en production.
- Le contenu de la landing page (`app/page.tsx`) a été reconstruit à
  partir de ton design original (variables CSS, polices, couleurs) — le
  fichier que tu m'as donné était coupé en plein milieu, donc certaines
  sections (carrousel vidéo, grille de fonctionnalités complète) sont
  simplifiées. Tu peux me remettre le fichier complet si tu veux que je
  les réintègre à l'identique.
