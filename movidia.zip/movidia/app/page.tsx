import Link from 'next/link';

export default function HomePage() {
  return (
    <>
      <div className="promo-banner">
        🎬 Offre de lancement — 7 jours d'essai sur l'abonnement Pro <span>Sans engagement</span>
      </div>

      <nav>
        <div className="nav-inner">
          <div className="logo syne">
            <span className="logo-icon">
              <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
            </span>
            Movidia
          </div>
          <div className="nav-links">
            <a href="#features">Fonctionnalités</a>
            <a href="#pricing">Tarifs</a>
          </div>
          <div className="nav-right">
            <Link href="/login" className="btn-ghost">Connexion</Link>
            <Link href="/signup" className="btn-primary" style={{ padding: '9px 20px', fontSize: 14 }}>Commencer</Link>
          </div>
        </div>
      </nav>

      <main>
        <section className="hero">
          <span className="hero-badge">
            <span className="hero-badge-dot" />
            Propulsé par Runway Gen-4.5
          </span>
          <h1 className="syne">
            Génère des vidéos <span className="grad">virales</span> avec l'IA
          </h1>
          <p className="hero-sub">
            Décris ton idée, l'IA génère la vidéo. Pour TikTok, Reels et YouTube Shorts — sans caméra, sans montage.
          </p>
          <div className="hero-actions">
            <Link href="/signup" className="btn-primary" style={{ padding: '15px 32px', fontSize: 16 }}>
              Créer mon compte gratuit
            </Link>
            <a href="#pricing" className="btn-ghost" style={{ padding: '15px 28px', fontSize: 15 }}>
              Voir les tarifs
            </a>
          </div>
          <p className="hero-note">Aucune carte bancaire requise pour créer un compte.</p>
        </section>

        <section id="pricing" className="section-pricing">
          <div className="wrap">
            <p className="section-eyebrow">TARIFS</p>
            <h2 className="section-title syne">Un seul plan, sans limite</h2>
            <p className="section-sub">Génère autant de vidéos IA que tu veux avec l'abonnement Pro.</p>

            <div className="pricing-grid">
              <div className="pricing-card">
                <h3>Gratuit</h3>
                <p className="price">0€</p>
                <ul>
                  <li>Accès au dashboard</li>
                  <li>Aucune génération vidéo incluse</li>
                </ul>
                <Link href="/signup" className="btn-ghost" style={{ display: 'block', textAlign: 'center' }}>
                  Créer un compte
                </Link>
              </div>

              <div className="pricing-card pricing-card-pro">
                <h3>Pro</h3>
                <p className="price">29€<span>/mois</span></p>
                <ul>
                  <li>Génération vidéo IA illimitée</li>
                  <li>Modèle Runway Gen-4.5</li>
                  <li>Vidéo de bienvenue générée automatiquement</li>
                  <li>Annulable à tout moment</li>
                </ul>
                <Link href="/signup" className="btn-primary" style={{ display: 'block', textAlign: 'center' }}>
                  S'abonner — Pro illimité
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <style>{`
        .section-pricing{padding:90px 0 110px;position:relative;z-index:1;}
        .section-eyebrow{font-size:12px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--violet-light);margin-bottom:14px;text-align:center;}
        .section-title{font-size:clamp(28px,4vw,42px);font-weight:800;letter-spacing:-.02em;text-align:center;margin-bottom:10px;}
        .section-sub{color:var(--text-dim);text-align:center;max-width:480px;margin:0 auto 50px;}
        .pricing-grid{display:grid;grid-template-columns:1fr 1fr;gap:24px;max-width:680px;margin:0 auto;}
        .pricing-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:32px;}
        .pricing-card h3{font-size:18px;font-weight:700;margin-bottom:10px;}
        .pricing-card .price{font-size:36px;font-weight:800;margin-bottom:22px;}
        .pricing-card .price span{font-size:14px;color:var(--text-dim);font-weight:500;}
        .pricing-card ul{list-style:none;margin-bottom:24px;}
        .pricing-card li{font-size:14px;color:var(--text-dim);padding:7px 0;border-top:1px solid var(--border);}
        .pricing-card li:first-child{border-top:none;}
        .pricing-card-pro{border-color:var(--violet);box-shadow:0 0 40px rgba(124,58,237,.2);}
        @media(max-width:640px){.pricing-grid{grid-template-columns:1fr;}}
      `}</style>
    </>
  );
}
