'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function SignupPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [sent, setSent] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: `${window.location.origin}/dashboard` },
    });

    if (error) {
      setError(error.message);
      setLoading(false);
      return;
    }

    // Marque automatiquement le compte comme "propriétaire" si l'email
    // correspond à celui défini côté serveur (OWNER_EMAIL).
    await fetch('/api/owner-claim', { method: 'POST' }).catch(() => {});

    if (data.session) {
      router.push('/dashboard');
    } else {
      setSent(true); // confirmation email requise selon config Supabase
    }
    setLoading(false);
  }

  return (
    <main className="auth-page">
      <div className="auth-card">
        <h1 className="syne">Créer un compte</h1>
        <p className="auth-sub">Génère tes premières vidéos IA en quelques minutes.</p>

        {sent ? (
          <p className="auth-success">Vérifie ta boîte mail pour confirmer ton compte.</p>
        ) : (
          <form onSubmit={handleSubmit}>
            <label>Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="toi@exemple.com" />
            <label>Mot de passe</label>
            <input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="6 caractères minimum" />
            {error && <p className="auth-error">{error}</p>}
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? 'Création…' : 'Créer mon compte'}
            </button>
          </form>
        )}

        <p className="auth-switch">Déjà un compte ? <a href="/login">Se connecter</a></p>
      </div>
    </main>
  );
}
