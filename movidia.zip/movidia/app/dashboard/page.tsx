'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

type Profile = { email: string; is_owner: boolean; plan: 'free' | 'pro'; subscription_status: string };
type Video = { id: string; prompt: string; status: string; video_url: string | null; created_at: string; auto_generated: boolean };

export default function DashboardPage() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [videos, setVideos] = useState<Video[]>([]);
  const [prompt, setPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();
  const supabase = createClient();

  async function loadAll() {
    const [p, v] = await Promise.all([
      fetch('/api/profile').then((r) => r.json()),
      fetch('/api/videos').then((r) => r.json()),
    ]);
    if (p.profile) setProfile(p.profile);
    if (v.videos) setVideos(v.videos);
  }

  useEffect(() => {
    loadAll();
    // Rafraîchit la liste toutes les 10s pour voir l'avancement des générations en cours
    const interval = setInterval(loadAll, 10000);
    return () => clearInterval(interval);
  }, []);

  async function handleGenerate(e: React.FormEvent) {
    e.preventDefault();
    setGenerating(true);
    setError('');
    const res = await fetch('/api/generate-video', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error || 'Une erreur est survenue.');
    } else {
      setPrompt('');
      await loadAll();
    }
    setGenerating(false);
  }

  async function handleSubscribe() {
    const res = await fetch('/api/stripe/checkout', { method: 'POST' });
    const data = await res.json();
    if (data.url) window.location.href = data.url;
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push('/login');
  }

  if (!profile) return <main className="dash-loading">Chargement…</main>;

  const canGenerate = profile.is_owner || (profile.plan === 'pro' && profile.subscription_status === 'active');

  return (
    <main className="dashboard">
      <header className="dash-header">
        <div className="logo syne">Movidia</div>
        <div className="dash-header-right">
          <span className="plan-badge">
            {profile.is_owner ? '👑 Propriétaire · Illimité' : profile.plan === 'pro' && profile.subscription_status === 'active' ? '✨ Pro · Illimité' : 'Compte gratuit'}
          </span>
          <button className="btn-ghost" onClick={handleLogout}>Déconnexion</button>
        </div>
      </header>

      <section className="dash-generate">
        <h2 className="syne">Générer une vidéo IA</h2>

        {!canGenerate && (
          <div className="upsell-card">
            <p>Passe en Pro pour générer des vidéos en illimité avec Runway Gen-4.5.</p>
            <button className="btn-primary" onClick={handleSubscribe}>S'abonner — Pro illimité</button>
          </div>
        )}

        <form onSubmit={handleGenerate}>
          <textarea
            placeholder="Décris la vidéo que tu veux générer : ambiance, action, style, lumière…"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            disabled={!canGenerate || generating}
            rows={3}
          />
          {error && <p className="auth-error">{error}</p>}
          <button type="submit" className="btn-primary" disabled={!canGenerate || generating || !prompt.trim()}>
            {generating ? 'Génération en cours (1-3 min)…' : 'Générer la vidéo'}
          </button>
        </form>
      </section>

      <section className="dash-videos">
        <h2 className="syne">Tes vidéos</h2>
        {videos.length === 0 && <p className="text-dim">Aucune vidéo pour le moment.</p>}
        <div className="video-grid">
          {videos.map((v) => (
            <div key={v.id} className="video-result-card">
              <p className="video-prompt">{v.prompt}</p>
              {v.status === 'completed' && v.video_url && (
                <video src={v.video_url} controls playsInline />
              )}
              {v.status === 'processing' && <p className="video-status">⏳ Génération en cours…</p>}
              {v.status === 'failed' && <p className="video-status error">❌ Échec de la génération</p>}
              {v.auto_generated && <span className="auto-tag">Auto · bienvenue</span>}
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
