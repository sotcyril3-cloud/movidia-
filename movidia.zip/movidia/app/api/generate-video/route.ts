import { NextRequest, NextResponse } from 'next/server';
import { createClient, createAdminClient } from '@/lib/supabase/server';
import { generateVideoFromText } from '@/lib/runway';
import { canGenerateVideo } from '@/lib/quota';

export const runtime = 'nodejs';
export const maxDuration = 300; // Runway peut prendre plusieurs minutes

export async function POST(req: NextRequest) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: 'Non authentifié.' }, { status: 401 });
  }

  const { prompt } = await req.json();
  if (!prompt || typeof prompt !== 'string' || prompt.trim().length < 3) {
    return NextResponse.json({ error: 'Décris la vidéo que tu veux générer.' }, { status: 400 });
  }

  const admin = createAdminClient();
  const { data: profile } = await admin
    .from('profiles')
    .select('is_owner, plan, subscription_status')
    .eq('id', user.id)
    .single();

  if (!profile) {
    return NextResponse.json({ error: 'Profil introuvable.' }, { status: 404 });
  }

  const check = canGenerateVideo(profile as any);
  if (!check.allowed) {
    return NextResponse.json({ error: check.reason }, { status: 403 });
  }

  const { data: videoRow } = await admin
    .from('videos')
    .insert({ user_id: user.id, prompt, status: 'processing' })
    .select()
    .single();

  const result = await generateVideoFromText(prompt);

  if (result.ok) {
    await admin
      .from('videos')
      .update({ status: 'completed', video_url: result.videoUrl, runway_task_id: result.taskId })
      .eq('id', videoRow!.id);
    return NextResponse.json({ ok: true, videoUrl: result.videoUrl, videoId: videoRow!.id });
  } else {
    await admin
      .from('videos')
      .update({ status: 'failed', error_message: result.error })
      .eq('id', videoRow!.id);
    return NextResponse.json({ error: result.error }, { status: 502 });
  }
}
