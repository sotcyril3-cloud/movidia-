import { NextRequest, NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { createAdminClient } from '@/lib/supabase/server';
import { generateVideoFromText } from '@/lib/runway';
import Stripe from 'stripe';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const body = await req.text();
  const sig = req.headers.get('stripe-signature')!;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err) {
    return NextResponse.json({ error: 'Signature webhook invalide.' }, { status: 400 });
  }

  const admin = createAdminClient();

  switch (event.type) {
    // L'utilisateur vient de payer pour la première fois
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session;
      const userId = session.metadata?.supabase_user_id;
      if (!userId) break;

      await admin
        .from('profiles')
        .update({
          plan: 'pro',
          subscription_status: 'active',
          stripe_subscription_id: session.subscription as string,
        })
        .eq('id', userId);

      // === Génération automatique de la vidéo IA juste après l'abonnement ===
      const { data: profile } = await admin
        .from('profiles')
        .select('email')
        .eq('id', userId)
        .single();

      // Crée d'abord la ligne "en cours" pour que le dashboard l'affiche tout de suite
      const { data: videoRow } = await admin
        .from('videos')
        .insert({
          user_id: userId,
          prompt: 'Vidéo de bienvenue générée automatiquement après votre abonnement Pro',
          status: 'processing',
          auto_generated: true,
        })
        .select()
        .single();

      // On ne bloque pas la réponse au webhook (Stripe attend une réponse rapide) :
      // la génération continue en tâche de fond.
      generateVideoFromText(
        `Une vidéo verticale dynamique et accueillante pour souhaiter la bienvenue à un nouvel abonné Pro de Movidia, style moderne, énergique, couleurs violet et rose néon`
      ).then(async (result) => {
        if (result.ok) {
          await admin
            .from('videos')
            .update({ status: 'completed', video_url: result.videoUrl, runway_task_id: result.taskId })
            .eq('id', videoRow?.id);
        } else {
          await admin
            .from('videos')
            .update({ status: 'failed', error_message: result.error })
            .eq('id', videoRow?.id);
        }
      });

      break;
    }

    // Renouvellement, annulation, échec de paiement, etc.
    case 'customer.subscription.updated':
    case 'customer.subscription.deleted': {
      const sub = event.data.object as Stripe.Subscription;
      const userId = sub.metadata?.supabase_user_id;
      if (!userId) break;

      const status =
        sub.status === 'active' ? 'active'
        : sub.status === 'past_due' ? 'past_due'
        : 'canceled';

      await admin
        .from('profiles')
        .update({
          subscription_status: status,
          plan: status === 'active' ? 'pro' : 'free',
        })
        .eq('id', userId);
      break;
    }
  }

  return NextResponse.json({ received: true });
}
