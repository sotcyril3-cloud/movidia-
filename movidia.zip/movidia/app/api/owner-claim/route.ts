import { NextResponse } from 'next/server';
import { createClient, createAdminClient } from '@/lib/supabase/server';

export async function POST() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ ok: false }, { status: 401 });

  const ownerEmail = process.env.OWNER_EMAIL?.toLowerCase().trim();
  if (ownerEmail && user.email?.toLowerCase().trim() === ownerEmail) {
    const admin = createAdminClient();
    await admin
      .from('profiles')
      .update({ is_owner: true, plan: 'pro', subscription_status: 'active' })
      .eq('id', user.id);
    return NextResponse.json({ ok: true, owner: true });
  }

  return NextResponse.json({ ok: true, owner: false });
}
