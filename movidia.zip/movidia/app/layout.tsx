import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: "Movidia — Génère des vidéos virales avec l'IA",
  description: "Transformez une idée en vidéo virale TikTok, Reels et YouTube Shorts grâce à l'IA.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
